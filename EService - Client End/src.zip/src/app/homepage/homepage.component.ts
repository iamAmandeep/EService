import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  constructor(private router:Router,private active:ActivatedRoute) { }

  jumboForm = new FormGroup(
    {
      city :new FormControl(''),
      category : new FormControl('')
    }
  );

  
  ngOnInit() {
  }

  
  submitJumboForm(){
    this.router.navigate( ['/combo/', {id: this.jumboForm.get('city').value, id2: this.jumboForm.get('category').value}]);
  }

  gotoadmin(){
    this.router.navigate(['/admin']);
  }

  gotoservices(){
    this.router.navigate(['/services']);
  }

  gotocity(){
    this.router.navigate(['/services/city']);
  }

  gotocategory(){
    this.router.navigate(['/services/category']);
  }

}
