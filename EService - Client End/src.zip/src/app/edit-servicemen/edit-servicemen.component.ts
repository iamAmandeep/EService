import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ServicemenService } from '../services/servicemen.service';

@Component({
  selector: 'app-edit-servicemen',
  templateUrl: './edit-servicemen.component.html',
  styleUrls: ['./edit-servicemen.component.css']
})
export class EditServicemenComponent implements OnInit {

  constructor(public formService:ServicemenService) { }

  ngOnInit() {
  }
  profileForm = new FormGroup(
    {
      Name:new FormControl(''),
      Category : new FormControl(''), 
      Mobile:new FormControl(''),
      Email : new FormControl(''), 
      City : new FormControl(''), 
      Experience:new FormControl(''),
      Rating : new FormControl(''), 
      })

      submitForm()
      {
        this.formService.Add(this.profileForm.value);
        console.log(this.profileForm.value);
        console.log("hi");
        alert("Sevicveman added Sucessfully");
      }

}
