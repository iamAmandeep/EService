import { Component, OnInit } from '@angular/core';
import { GetAllService } from '../services/get-all.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  allService=[];
  constructor(private getAllLink:GetAllService,private router:Router,private active:ActivatedRoute) { }

  getAServices(){
    this.getAllLink.getAllServices().subscribe(resp=>this.allService=resp.json());
    console.log(this.allService);
  }

  gotoAdd(){
    this.router.navigate(['/admin/add']);
  }

  ngOnInit() {
  }

}
