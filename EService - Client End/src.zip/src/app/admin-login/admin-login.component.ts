import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../services/admin-service.service';
import{FormGroup} from '@angular/forms';
import{FormControl} from '@angular/forms';
@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  constructor(public formService:AdminServiceService) { }

  ngOnInit() {
  }

  profileForm = new FormGroup(
    {
      Username:new FormControl(''),
      Password : new FormControl(''), 
      })

      submitForm()
      {
        this.formService.Add(this.profileForm.value);
        console.log(this.profileForm.value);
      }

    }
   
  
  
  

